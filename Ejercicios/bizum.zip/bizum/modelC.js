const contraseña = document.querySelector("input[type='password']");
const teclado = document.getElementById("teclado");
const ojo = document.querySelectorAll(".ojo");
const dni = document.querySelector("input[type='text']");
const entrarBtn = document.getElementById("entrar");
const main = document.querySelector("main");
const p = document.querySelector("header p");

// Función para agregar números al campo de contraseña
function numero(num) {
    contraseña.value += num;
}

// Mostrar teclado al hacer foco en el campo de contraseña
contraseña.addEventListener("focus", function () {
    teclado.style.display = "block";
});

// Alternar visibilidad de la contraseña
ojo.forEach((img) => {
    img.addEventListener("click", function () {
        if (contraseña.type === "password") {
            contraseña.type = "text";  
            ojo[0].classList.add("oculto");
            ojo[1].classList.remove("oculto");
        } else {
            contraseña.type = "password";
            ojo[1].classList.add("oculto");
            ojo[0].classList.remove("oculto");
        }
    });
});

// Añadir funcionalidad a las imágenes del teclado
teclado.querySelectorAll("li img").forEach((img, index) => {
    img.addEventListener("click", function () {
        numero(index.toString());
    });
});

// Validar y procesar el formulario al hacer clic en "entrar"
entrarBtn.addEventListener("click", function (event) {
    event.preventDefault(); // Evitar que el formulario se envíe

    const dniValue = dni.value;
    const contraseñaValue = contraseña.value;

    if (dniValue === "" && contraseñaValue === "") {
        alert('Debes introducir el DNI y la contraseña \n Inténtalo de nuevo.');
    } else if (dniValue === "") {
        alert('Debes introducir el DNI \n Inténtalo de nuevo.');
    } else if (contraseñaValue === "") {
        alert('Debes introducir tu Contraseña \n Inténtalo de nuevo.');
    } else if (dniValue.length !== 9) {
        alert('El DNI debe tener 9 carácteres \n Inténtalo de nuevo.');
    } else {
        main.remove();
        p.remove(); 
        const listaContenedor = document.getElementById('id'); // Asegúrate de que este ID exista en tu HTML
        const nuevoElemento = document.createElement('p'); // Crear un nuevo elemento <p>
        nuevoElemento.textContent = "Bizum realizado"; // Establecer el texto del nuevo elemento
        listaContenedor.appendChild(nuevoElemento); // Agregar el nuevo elemento al contenedor
    }

});



