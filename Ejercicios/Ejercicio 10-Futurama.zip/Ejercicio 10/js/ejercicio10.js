
const area = document.getElementsByTagName('textarea')[0];
const numero = document.getElementsByTagName('span')[0];
const select = document.getElementsByTagName('select')[0]; 

const avatar = new Map([
    ["Ninguno", "img/avatar.png"],
    ["Fry", "img/Fry.ico"],
    ["Bender", "img/Bender.ico"],
    ["Leela", "img/Leela.ico"],
    ["Farnsworth", "img/Farnsworth.ico"],
    ["Hermes", "img/Hermes.ico"],
    ["Nibbler", "img/Nibbler.ico"],
    ["Scruffy", "img/Scruffy.ico"],
    ["Zoidberg", "img/Zoidberg.ico"],
    ["Amy", "img/Amy.ico"]
]);

let palabras = 0;

Countable.on(area, counter => {
    palabras = counter.words;
    numero.textContent = palabras;
    if (counter.words>10){
        numero.style.color='red';
    }else{
        numero.style.color='black';
    }
});

select.addEventListener('change', () => {
    const seleccionado = select.value;
    const imagen = avatar.get(seleccionado);
    document.getElementsByTagName('img')[0].src = imagen;
});

document.getElementsByTagName('button')[0].addEventListener('click', () => {
    const seleccionado = select.value;

    if (area.value === '') {
        alert('Tienes que escribir un mensaje');
    } else if (palabras > 10) {
        alert('El mensaje debe tener menos de 10 palabras');
    } else if (seleccionado === "Ninguno") {
        alert('Tienes que seleccionar un avatar');
    } else {
        const modal = document.querySelector('[data-remodal-id=preview-modal]');
        const seleccionado = select.value;
        const imagen = avatar.get(seleccionado);
        document.getElementById('foto').src = imagen;
        document.getElementById('mensaje').textContent=area.value;
        
        const instance = $(modal).remodal(); 
        instance.open();
    }
});
